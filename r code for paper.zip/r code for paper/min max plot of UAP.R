quantile_INH <- function(n,alpha,beta){
u=runif(n)
tt=(1-(1-u)^(1/log(alpha)))^(1/beta) 
return(tt)
}
#############################
# function for estimated Min order statistics
minord <- function(x,t){ 
    n = length(x)  
    i = 1:n
    x = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(n-i,t-1)*x
        c1*sum(t1)}

# function for estimated Max order statistic
maxord <- function(x,t){
   n  = length(x) 
   i  = 1:n 
   x  = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(i-1,t-1)*x
        c1*sum(t1)}
		########################################
		n = 100; k = 1:n  # no. of observations
 y<-quantile_INH(n,1.5,1.2)  # simulated exp. data
 wdy = 0; woy = 0

 for (i in 1:n){
  wdy[i] = minord(y,i) # estimate min order stat.
  woy[i] = maxord(y,i) # estimate Max order stat.
}

plot(wdy, ylim = c(min(wdy),max(woy)),ylab = "Min-Max", 
     main = "Simulated plot of Min-Max for APU",col = "red",lwd=4,type="l", lty=1)
points(woy , col = "red", lwd=4,type="l", lty=1)
abline(h=mean(y),col="blue",lwd=4)
legend("center",c(expression(alpha==1.5, beta==1.2)),lty=1, col="blue", lwd=4, text.col="blue",bty="n",cex=1.2)

###################################################################################
###################################################################################
quantile_INH <- function(n,alpha,beta){
u=runif(n)
tt=(1-(1-u)^(1/log(alpha)))^(1/beta) 
return(tt)
}
#############################
# function for estimated Min order statistics
minord <- function(x,t){ 
    n = length(x)  
    i = 1:n
    x = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(n-i,t-1)*x
        c1*sum(t1)}

# function for estimated Max order statistic
maxord <- function(x,t){
   n  = length(x) 
   i  = 1:n 
   x  = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(i-1,t-1)*x
        c1*sum(t1)}
		########################################
		n = 100; k = 1:n  # no. of observations
 y<-quantile_INH(n,1.8,1.3)  # simulated exp. data
 wdy = 0; woy = 0

 for (i in 1:n){
  wdy[i] = minord(y,i) # estimate min order stat.
  woy[i] = maxord(y,i) # estimate Max order stat.
}

plot(wdy, ylim = c(min(wdy),max(woy)),ylab = "Min-Max", 
     main = "Simulated plot of Min-Max for APU",col = "red",lwd=4,type="l", lty=1)
points(woy , col = "red", lwd=4,type="l", lty=1)
abline(h=mean(y),col="blue",lwd=4)
legend("center",c(expression(alpha==1.8, beta==1.3)),lty=1, col="blue", lwd=4, text.col="blue",bty="n",cex=1.2)


###################################################################################
###################################################################################
quantile_INH <- function(n,alpha,beta){
u=runif(n)
tt=(1-(1-u)^(1/log(alpha)))^(1/beta)
return(tt)
}

#############################
# function for estimated Min order statistics
minord <- function(x,t){ 
    n = length(x)  
    i = 1:n
    x = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(n-i,t-1)*x
        c1*sum(t1)}

# function for estimated Max order statistic
maxord <- function(x,t){
   n  = length(x) 
   i  = 1:n 
   x  = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(i-1,t-1)*x
        c1*sum(t1)}
		########################################
		n = 100; k = 1:n  # no. of observations
 y<-quantile_INH(n,2.0,1.5)  # simulated exp. data
 wdy = 0; woy = 0

 for (i in 1:n){
  wdy[i] = minord(y,i) # estimate min order stat.
  woy[i] = maxord(y,i) # estimate Max order stat.
}

plot(wdy, ylim = c(min(wdy),max(woy)),ylab = "Min-Max", 
     main = "Simulated plot of Min-Max for APU",col = "red",lwd=4,type="l", lty=1)
points(woy , col = "red", lwd=4,type="l", lty=1)
abline(h=mean(y),col="blue",lwd=4)
legend("center",c(expression(alpha==2.0, beta==1.5)),lty=1, col="blue", lwd=4, text.col="blue",bty="n",,cex=1.2)

###################################################################################
###################################################################################
quantile_INH <- function(n,alpha,beta){
u=runif(n)
tt=(1-(1-u)^(1/log(alpha)))^(1/beta)
return(tt)
}

#############################
# function for estimated Min order statistics
minord <- function(x,t){ 
    n = length(x)  
    i = 1:n
    x = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(n-i,t-1)*x
        c1*sum(t1)}

# function for estimated Max order statistic
maxord <- function(x,t){
   n  = length(x) 
   i  = 1:n 
   x  = sort(x)
   c1 = 1/choose(n,t)
   t1 = choose(i-1,t-1)*x
        c1*sum(t1)}
		########################################
		n = 100; k = 1:n  # no. of observations
 y<-quantile_INH(n,2.2,1.7)  # simulated exp. data
 wdy = 0; woy = 0

 for (i in 1:n){
  wdy[i] = minord(y,i) # estimate min order stat.
  woy[i] = maxord(y,i) # estimate Max order stat.
}

plot(wdy, ylim = c(min(wdy),max(woy)),ylab = "Min-Max", 
     main = "Simulated plot of Min-Max for APU",col = "red",lwd=4,type="l", lty=1)
points(woy , col = "red", lwd=4,type="l", lty=1)
abline(h=mean(y),col="blue",lwd=4)
legend("center",c(expression(alpha==2.2, beta==1.7)),lty=1, col="blue", lwd=4, text.col="blue",bty="n",cex=1.2)

