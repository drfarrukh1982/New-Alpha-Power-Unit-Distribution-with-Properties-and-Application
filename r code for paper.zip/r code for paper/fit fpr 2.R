for change data and pdf and cdf we get variance - covariance matrix for any distribution.

######################## DATA SET ####################################


x=c(0.4365, 0.4260, 0.5140, 0.6907, 0.7471, 0.2605, 0.6196, 0.8781, 0.4990,0.6058, 0.6891, 0.5770, 0.5394, 0.1479, 0.2356, 0.6012, 0.1525, 0.5483, 0.6927, 0.7261,
0.3323, 0.0671, 0.2361, 0.4800, 0.5707, 0.7131, 0.5853, 0.6768, 0.5350, 0.4151, 0.6789,
0.4576, 0.3259, 0.2303, 0.7687, 0.4371, 0.3383, 0.6114, 0.3480, 0.4564, 0.7804, 0.3406,
0.4823, 0.5912, 0.5744, 0.5481, 0.1131, 0.7290, 0.0168, 0.5529, 0.4530, 0.3891, 0.4752,
0.3134, 0.3175, 0.1167, 0.6750, 0.5113, 0.5447, 0.4143, 0.5627, 0.5150, 0.0776, 0.3945,
0.4553, 0.4470, 0.5285, 0.5232, 0.6465, 0.0650, 0.8492, 0.8147, 0.3627, 0.3906, 0.4438,
0.4612, 0.3188, 0.2160, 0.6707, 0.6220, 0.5629, 0.4675, 0.6844, 0.3413, 0.4332, 0.0854,
0.3821, 0.4694, 0.3635, 0.4111, 0.5349, 0.3751, 0.1546, 0.4517, 0.2681, 0.4049, 0.5553,
0.5878, 0.4741, 0.3598, 0.7629, 0.5941, 0.6174, 0.6860, 0.0609, 0.6488, 0.2747)

n=length(x)
##############################
library(fitdistrplus)

dgpl=function(x,beta,alpha)
{


f=(beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta)


}

pgpl=function(q,beta,alpha){

F=1-alpha^(log(1-q^beta))
}

qgpl=function(p,beta,alpha){
f=function(p){
g=function(x,p) pgpl(x,beta,alpha)-p
uniroot(g, c(0, 1), p=p)$root
}
apply(as.matrix(p), 1, f)
}

fitg1 <-fitdist(x, "gpl",optim.method="SANN", start=list(  alpha=13.77851650,beta= 0.8401662 ), method="mle")
plot(fitg1, demp =T)

par (mfrow=c (2,2))



ppcomp(fitg1,fitcol=2,legendtext="APU",lwd=3)
qqcomp(fitg1,fitcol=2,legendtext="APU",lwd=3)
denscomp(fitg1,fitcol=2,legendtext="APU",fitlwd=3)

cdfcomp(fitg1,fitcol=2,legendtext="APU",fitlwd=3)

box()
summary(fitg1)
vcov( fitg1, part = "outcome" )

box()
	


