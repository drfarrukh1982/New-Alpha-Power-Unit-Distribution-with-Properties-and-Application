
rm(list=ls())

F <- function(x,par){

  alpha<-par[1];beta<-par[2]

C<-(1-alpha^(log(1-x^beta)))

D<-((beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta))

 return(C)}

#------------------------------------------------------------------------

f <- function(x,par){

  alpha<-par[1];beta<-par[2]

C<-(1-alpha^(log(1-x^beta)))

D<-((beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta))

 return(D)}

#------------------------------------------------------------------------

h <- function(x,par){f(x,par)/(1-F(x,par))}

#------------------------------Random Sample of X------------------------------------------

r <- 200

n <- seq(20,100,5)

p_alpha <-3.8

p_beta <-2.0




alpha_mle=beta_mle=bias_alpha1=bias_beta1=c()

MSE1_alpha= MSE1_beta=c()

bias_alpha=bias_beta=MSE_alpha= MSE_beta=c()

#-----------------------

curve(F(x,c(p_alpha,p_beta)),lwd=2,ylim=c(0,5),xlim=c(0,1))



#-----------------------------------------------------------------------

F_x = function(x) F(x,c(p_alpha,p_beta))

#-----------------------------------------------------------------------

inverse = function(u, lower, upper) {

uniroot((function (x) F_x(x)- u), lower = lower, upper = upper)$root}

#######I must test inverse value for bounded of runif in below function########

inverse (0.1,0.00000000000000000001,1)

#inverse (0.005,-10,5)

#inverse (1,-10,21)

#-----------------------------------------------------------------------

X_generator <- function(n, lower, upper){

U <- runif(n,0.00000000000000000001,1)

X <- c()

for (i in 1:n){

  X[i]=inverse(U[i], lower, upper)}

return(X)}

X_generator(100,0,1)

#-------------------------------------------------------------------------

library(maxLik)

LikFun_f <- function(x,par){

  alpha<-par[1];beta<-par[2]



  D<-prod(((beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta)))

return(D)}

#-------------------------------------------------------------------------

for (k in 1:length(n)){

 for (j in 1:r){

X <- X_generator(n[k],0,1)

MLE <- optim(par <- c(p_alpha,p_beta),

fn=LikFun_f,x=X)#,method="BFGS")

alpha_mle[j]<- MLE$par[1]
beta_mle[j]<- MLE$par[2]

bias_alpha1[j] <- alpha_mle[j]-p_alpha
bias_beta1[j] <- beta_mle[j]-p_beta


MSE1_alpha[j]<-(bias_alpha1[j])^2

MSE1_beta[j]<-(bias_beta1[j])^2


}


bias_alpha[k]<- mean(bias_alpha1)
bias_beta[k]<- mean(bias_beta1)

MSE_alpha[k]<- mean(MSE1_alpha)
MSE_beta[k]<- mean(MSE1_beta)


}

#-------------------------------Beep------------------------------------------

library(beepr)

beep(3)

#------------------------------Bias---Plot----------------------------------------#
par (mfrow=c (2,2))

plot(n,bias_alpha,typ="l" ,ylab=expression(paste(bias(alpha))),lwd=2)

plot(n,bias_beta,typ="l" ,ylab=expression(paste(bias(beta))),lwd=2)


#------------------------------MSE---Plot-----------------------------------------#

#par (mfrow=c (2,2))

plot(n,MSE_alpha,typ="l" ,ylab=expression(paste(MSE(alpha))),lwd=2)

plot(n,MSE_beta,typ="l" ,ylab=expression(paste(MSE(beta))),lwd=2)



