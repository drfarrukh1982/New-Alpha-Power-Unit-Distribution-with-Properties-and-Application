	 
x<- c(  0.0009, 0.004, 0.0142, 0.0221, 0.0261, 0.0418, 0.0473,
0.0834, 0.1091, 0.1252, 0.1404, 0.1498, 0.175, 0.2031, 0.2099, 0.2168, 0.2918,
0.3465, 0.4035, 0.6143)

dados<- c(  0.0009, 0.004, 0.0142, 0.0221, 0.0261, 0.0418, 0.0473,
0.0834, 0.1091, 0.1252, 0.1404, 0.1498, 0.175, 0.2031, 0.2099, 0.2168, 0.2918,
0.3465, 0.4035, 0.6143 )

hist(x, prob=T)

TTT(x,col=2)

boxplot(x,col=2)
library(AdequacyModel)

#install.packages('AdequacyModel')

library(psych)
describe(x)
############T

############
############################################################

pdf_L<- function(par,x){
alpha=par[1]
beta=par[2]
F=1-alpha^(log(1-x^beta))

f=(beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta)
  return(f)
  }
  cdf_L<-function(par,x){
alpha=par[1]
beta=par[2]
F=1-alpha^(log(1-x^beta))

f=(beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta)
  return(F)
  }
cdf_L(c(1.5,2.5),1)


res_L=goodness.fit(pdf=pdf_L, cdf=cdf_L, 
starts=c(31.0954251 , 0.7638004),
method="B", data=x, domain=c(0,1),mle=NULL)
res_L
############T
#Power Burr Hatke
############
############################################################

pdf_B<- function(par,x){

beta=par[1]
lambda=par[2]

F=1-(1+x^beta)^(-lambda)*exp(-lambda*x^beta)
f=beta*lambda*(x^(beta-1))*((x^beta)+2)*((1+x^beta)^(-lambda-1))*exp(-lambda*x^beta)
return(f)
  }
  cdf_B<-function(par,x){
beta=par[1]
lambda=par[2]

F=1-(1+x^beta)^(-lambda)*exp(-lambda*x^beta)
f=beta*lambda*(x^(beta-1))*((x^beta)+2)*((1+x^beta)^(-lambda-1))*exp(-lambda*x^beta)
return(F)
  }
cdf_B(c(.2,3),Inf)


res_B=goodness.fit(pdf=pdf_B, cdf=cdf_B, 
starts=c( 0.9297047, 3.0010796  ),
method="B", data=x, domain=c(0,Inf),mle=NULL)

#########################
#########################
############
############T
# Burr Hatke
############
############################################################

pdf_B1<- function(par,x){

lambda=par[1]

F=1-(1+x)^(-1)*exp(-lambda*x)
f=(lambda*(x+1)+1)*((1+x)^(-2))*exp(-lambda*x)
return(f)
  }
  cdf_B1<-function(par,x){
lambda=par[1]
F=1-(1+x)^(-1)*exp(-lambda*x)
f=(lambda*(x+1)+1)*((1+x)^(-2))*exp(-lambda*x)
return(F)
  }
cdf_B1(c(.2,3),0)

res_B1=goodness.fit(pdf=pdf_B1, cdf=cdf_B1, 
starts=c(1.98177  ),
method="B", data=x, domain=c(0,Inf),mle=NULL)

res_B1
########################
#BX
############
############################################################

pdf_B1e<- function(par,x){

lambda=par[1]
theta=par[2]
F=(1-exp((-lambda^2)*x^2))^theta
f=2*(lambda^2)*theta*x*exp((-lambda^2)*x^2)*(1-exp((-lambda^2)*x^2))^(theta-1)
return(f)
  }
  cdf_B1e<-function(par,x){

lambda=par[1]
theta=par[2]
F=(1-exp((-lambda^2)*x^2))^theta
f=2*(lambda^2)*theta*x*exp((-lambda^2)*x^2)*(1-exp((-lambda^2)*x^2))^(theta-1)
return(F)
  }
cdf_B1(c(.2,3),0)

res_B1e=goodness.fit(pdf=pdf_B1e, cdf=cdf_B1e, starts=c( -2.9193338 , 0.3158593 ),
method="B", data=x, domain=c(0,Inf),mle=NULL)

########################
KU
############################################################

pdf_llk<- function(par,x){
b=par[1]
a=par[2]
F=1-(1-x^a)^b
f=a*b*x^(a-1)*(1-x^a)^(b-1)

  return(f)
  }
  cdf_llk<-function(par,x){
b=par[1]
a=1
F=1-(1-x^a)^b
f=a*b*x^(a-1)*(1-x^a)^(b-1)
  return(F)
  }
cdf_ll(c(.2,.2),1)


res_llk=goodness.fit(pdf=pdf_llk, cdf=cdf_llk, 
starts=c( 3.4577387, 0.7678496 ),
method="B", data=x, domain=c(0,1),mle=NULL)

########################
########
########################
#Beta
############
############################################################

pdf_llb<- function(par,x){
a=par[1]
b=par[2]

F=pbeta(x,a,b)
f=dbeta(x,a,b)
  return(f)
  }
  cdf_llb<-function(par,x){
a=par[1]
b=par[2]

F=pbeta(x,a,b)
f=dbeta(x,a,b)
  return(F)
  }
cdf_ll(c(.2,.2),1)


res_llb=goodness.fit(pdf=pdf_llb, cdf=cdf_llb, 
starts=c(0.7153109 ,3.7786021 ),
method="B", data=x, domain=c(0,1),mle=NULL)
############
############
#Burr XII
############T
############
############################################################

pdf_B12<- function(par,x){

alpha=par[1]
beta=par[2]



F=1-exp(-alpha*x^beta)
f=alpha*beta*x^(beta-1)*exp(-alpha*x^beta)
return(f)
  }
  cdf_B12<-function(par,x){
alpha=par[1]
beta=par[2]



F=1-exp(-alpha*x^beta)
f=alpha*beta*x^(beta-1)*exp(-alpha*x^beta)
return(F)
  }
cdf_B(c(.2,3),Inf)


res_B12=goodness.fit(pdf=pdf_B12, cdf=cdf_B12, 
starts=c(5.3599216, 0.8991151  ),
method="B", data=x, domain=c(0,Inf),mle=NULL)


#########################
#############################################
############
#LOG LINDLY DIST
############T
############
############################################################

pdf_rt<- function(par,x){

alpha=par[1]
beta=par[2]



F=(x^(alpha)*(1+alpha*beta-alpha*log(x))/(1+alpha*beta))
f=(alpha^2*(beta-log(x))*x^(alpha-1)/(1+alpha*beta))
return(f)
  }
  cdf_rt<-function(par,x){
alpha=par[1]
beta=par[2]



F=(x^(alpha)*(1+alpha*beta-alpha*log(x))/(1+alpha*beta))
f=(alpha^2*(beta-log(x))*x^(alpha-1)/(1+alpha*beta))
return(F)
  }
cdf_rt(c(2.5,1.6),0.1)

res_rt=goodness.fit(pdf=pdf_rt, cdf=cdf_rt, 
starts=c(2.7 ,2.0 ),
method="S", data=x, domain=c(0.1,1),mle=NULL)

#########################
#############################################
############
#unit gompertz distribution
############T
############
############################################################

pdf_g1<- function(par,x){

alpha=par[1]
beta=par[2]



F=exp(alpha*(1-x^(-beta)))
f=alpha*beta*x^(-(beta+1))*exp(alpha*(1-x^(-beta)))
return(f)
  }
  cdf_g1<-function(par,x){
alpha=par[1]
beta=par[2]



F=exp(alpha*(1-x^(-beta)))
f=alpha*beta*x^(-(beta+1))*exp(alpha*(1-x^(-beta)))
return(F)
  }
cdf_g1(c(.2,3),0)


res_g1=goodness.fit(pdf=pdf_g1, cdf=cdf_g1, 
starts=c( 0.8081084 ,0.2710698  ),
method="B", data=x, domain=c(0,1),mle=NULL)


#########################
#############################################
hist(x,probability = T, ylim = c(0,2), main = "", ylab = "pdf", xlab = "x", col = "gray90")
box()
grid()



curve(pdf_L(res_L$mle,x), add=T,lty=1,col=9,lwd=3)
curve(pdf_B(res_B$mle,x), add=T,lty=2,col=3,lwd=3)
curve(pdf_B1e(res_B1e$mle,x), add=T,lty=3,col=4,lwd=3)
curve(pdf_llk(res_llk$mle,x), add=T,lty=4,col=5,lwd=3)
curve(pdf_B12(res_B12$mle,x), add=T,lty=5,col=6,lwd=3)
curve(pdf_g1(res_g1$mle,x), add=T,lty=6,col=7,lwd=3)


legend("topright",c("NAP","PBH","BX","BX11","UGD"),lwd=c(3,3,3,3,3),
       lty=c(9,2,4,5,6),col=c(9,2,4,5,6), bg="gray90", box.lwd = .1,cex = 1)

box()

##########
######		  Estimated cdf ( APP # 1)		######
############################################################

x <- seq(0,0.5, length.out = 200)
plot(ecdf(dados), lty=1, lwd=2, do.points=FALSE, verticals=TRUE, 
     ylim=c(0.0,1), ylab="cdf", main="", col.01line="white",pch=4,cex=2)
grid()
curve(cdf_L(res_L$mle,x), add=T,lty=1,col=9,lwd=3)
curve(cdf_B(res_B$mle,x), add=T,lty=2,col=3,lwd=3)
curve(cdf_B1e(res_B1e$mle,x), add=T,lty=3,col=4,lwd=3)
curve(cdf_llk(res_llk$mle,x), add=T,lty=4,col=5,lwd=3)
curve(cdf_B12(res_B12$mle,x), add=T,lty=5,col=7,lwd=3)
curve(cdf_g1(res_g1$mle,x), add=T,lty=6,col=8,lwd=3)


legend("topleft",c("UAP","PBH","BX","KU","BX11","UGD"),lwd=c(3,3,4,3,3,3,3,3,3),
       lty=c(1,2,3,4,5,6,7),col=c(2,3,4,5,7,8), bg="gray90", box.lwd = .1,cex = 1)

box()

