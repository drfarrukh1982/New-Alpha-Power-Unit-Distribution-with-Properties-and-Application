x<- c(0.853, 0.759, 0.866, 0.809, 0.717, 0.544, 0.492, 0.403, 0.344, 0.213, 0.116, 0.116, 0.092,
0.070, 0.059, 0.048, 0.036, 0.029, 0.021, 0.014, 0.011, 0.008, 0.006)

dados<- c(0.853, 0.759, 0.866, 0.809, 0.717, 0.544, 0.492, 0.403, 0.344, 0.213, 0.116, 0.116, 0.092,
0.070, 0.059, 0.048, 0.036, 0.029, 0.021, 0.014, 0.011, 0.008, 0.006)

hist(x, prob=T)

TTT(x,col=2)

boxplot(x,col=2)
library(AdequacyModel)
library(psych)
#install.packages('psych')
describe(x)
############T
#SineG
############
############################################################

pdf_llsg<- function(par,x){
alpha=par[1]

F=(2*sin((pi/2)*x^alpha))/(1+sin((pi/2)*x^alpha))

f=(alpha*pi*x^(alpha-1)*cos((pi/2)*x^alpha))/(1+sin((pi/2)*x^alpha))^2

  return(f)
  }
  cdf_llsg<-function(par,x){
alpha=par[1]

F=(2*sin((pi/2)*x^alpha))/(1+sin((pi/2)*x^alpha))

f=(alpha*pi*x^(alpha-1)*cos((pi/2)*x^alpha))/(1+sin((pi/2)*x^alpha))^2
  return(F)
  }
cdf_llsg(c(.2),1)


res_llsg=goodness.fit(pdf=pdf_llsg, cdf=cdf_llsg, 
starts=c(  0.7903873),
method="B", data=x, domain=c(0,1),mle=NULL)
############

############T
#UR
############
############################################################

pdf_ll<- function(par,x){
beta=par[1]

F=exp(-beta*(log(x))^2)
f=((-2*beta)/x)*log(x)*exp(-beta*(log(x))^2)

  return(f)
  }
  cdf_ll<-function(par,x){
beta=par[1]
F=exp(-beta*(log(x))^2)
f=((-2*beta)/x)*log(x)*exp(-beta*(log(x))^2)
  return(F)
  }
cdf_ll(c(.2),1)


res_ll=goodness.fit(pdf=pdf_ll, cdf=cdf_ll, 
starts=c(   0.7903873),
method="B", data=x, domain=c(0,1),mle=NULL)
############
#KU
############################################################

pdf_llk<- function(par,x){
b=par[1]
a=1
F=1-(1-x^a)^b
f=a*b*x^(a-1)*(1-x^a)^(b-1)

  return(f)
  }
  cdf_llk<-function(par,x){
b=par[1]
a=1
F=1-(1-x^a)^b
f=a*b*x^(a-1)*(1-x^a)^(b-1)
  return(F)
  }
cdf_ll(c(.2),1)


res_llk=goodness.fit(pdf=pdf_llk, cdf=cdf_llk, 
starts=c(  1.19371),
method="B", data=x, domain=c(0,1),mle=NULL)
########################
########
########################
#Topp
############
############################################################

pdf_llt<- function(par,x){
v=par[1]

F=((2-x)^v)*x^v
f=2*v*(1-x)*x^(v-1)*(2-x)^(v-1)

  return(f)
  }
  cdf_llt<-function(par,x){
v=par[1]

F=((2-x)^v)*x^v
f=2*v*(1-x)*x^(v-1)*(2-x)^(v-1)

  return(F)
  }
cdf_ll(c(.2),1)


res_llt=goodness.fit(pdf=pdf_llt, cdf=cdf_llt, 
starts=c( 0.6017149),
method="B", data=x, domain=c(0,1),mle=NULL)
############
########################
############
#Beta
############
############################################################

pdf_llb<- function(par,x){
a=par[1]
b=2

F=pbeta(x,a,b)
f=dbeta(x,a,b)
  return(f)
  }
  cdf_llb<-function(par,x){
a=par[1]
b=2

F=pbeta(x,a,b)
f=dbeta(x,a,b)
  return(F)
  }
cdf_ll(c(.2),1)


res_llb=goodness.fit(pdf=pdf_llb, cdf=cdf_llb, 
starts=c(0.622879),
method="B", data=x, domain=c(0,1),mle=NULL)
############
############
#Power
############
############################################################

pdf_llp<- function(par,x){
a=par[1]
F=x^a
f=a*x^(a-1)
  return(f)
  }
  cdf_llp<-function(par,x){
a=par[1]
F=x^a
f=a*x^(a-1)
  return(F)
  }
cdf_ll(c(.2),1)


res_llp=goodness.fit(pdf=pdf_llp, cdf=cdf_llp, 
starts=c(  1.3288),
method="B", data=x, domain=c(0,1),mle=NULL)
############
############
############
#Transmuted
############
############################################################

pdf_llTM<- function(par,x){
a=par[1]
F=(1+a)*x-a*x^2
f=1+a-2*a*x

  return(f)
  }
  cdf_llTM<-function(par,x){
a=par[1]
F=(1+a)*x-a*x^2
f=1+a-2*a*x

  return(F)
  }
cdf_ll(c(.2),1)


res_llTM=goodness.fit(pdf=pdf_llTM, cdf=cdf_llTM, 
starts=c( 0.8947),
method="S", data=x, domain=c(0,1),mle=NULL)
############
############

########################
############
########################
#############################################
hist(x,probability = T, ylim = c(0,4), main = "", ylab = "pdf", xlab = "x", col = "gray90")
box()
grid()



curve(pdf_llsg(res_llsg$mle,x), add=T,lty=1,col=2,lwd=3)
curve(pdf_ll(res_ll$mle,x), add=T,lty=2,col=3,lwd=3)
curve(pdf_llk(res_llk$mle,x), add=T,lty=3,col=4,lwd=3)
curve(pdf_llt(res_llt$mle,x), add=T,lty=4,col=5,lwd=3)
curve(pdf_llb(res_llb$mle,x), add=T,lty=5,col=6,lwd=3)
curve(pdf_llp(res_llp$mle,x), add=T,lty=6,col=7,lwd=3)
curve(pdf_llTM(res_llTM$mle,x), add=T,lty=7,col=8,lwd=3)

legend("topright",c("SING","UR","Ku","TL","B","P","TM"),lwd=c(3,3,4,3,3,3,3,3,3),
       lty=c(1,2,3,4,5,6,7,8),col=c(2,3,4,5,6,7,8,9), bg="gray90", box.lwd = .1,cex = 1)

box()

##########
######		  Estimated cdf ( APP # 1)		######
############################################################

x <- seq(0,0.5, length.out = 200)
plot(ecdf(dados), lty=1, lwd=2, do.points=FALSE, verticals=TRUE, 
     ylim=c(0.0,1), ylab="cdf", main="", col.01line="white",pch=4,cex=2)
grid()
curve(cdf_llsg(res_llsg$mle,x), add=T,lty=1,col=2,lwd=3)
curve(cdf_ll(res_ll$mle,x), add=T,lty=2,col=3,lwd=3)
curve(cdf_llk(res_llk$mle,x), add=T,lty=3,col=4,lwd=3)
curve(cdf_llt(res_llt$mle,x), add=T,lty=4,col=5,lwd=3)
curve(cdf_llb(res_llb$mle,x), add=T,lty=5,col=6,lwd=3)
curve(cdf_llp(res_llp$mle,x), add=T,lty=6,col=7,lwd=3)
curve(cdf_llTM(res_llTM$mle,x), add=T,lty=7,col=8,lwd=3)

legend("topleft",c("SING","UR","Ku","TL","B","P","TM"),lwd=c(3,3,4,3,3,3,3,3,3),
       lty=c(1,2,3,4,5,6,7,8),col=c(2,3,4,5,6,7,8,9), bg="gray90", box.lwd = .1,cex = 1)

box()
