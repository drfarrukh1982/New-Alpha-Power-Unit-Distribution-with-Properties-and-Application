
# UNIT ALPHA POWER DISTRIBUTION
deb <- function(alpha,beta,x){
F=1-alpha^(log(1-x^beta))

f=(beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta)
h=f/(1-F)  
return(h)
 }
 
 deb(2.9579795,1.2015028 ,0)
curve(deb(1.1,0.0001,x),ylim=c(0,2),xlim=c(0,1),ylab="hrf",lwd=4)
curve(deb(1.5,0.2,x),add=T,lty=2,col=2,lwd=4)

 curve(deb(1.9579795,1.5015028 ,x),add=T,lty=3,col=3,lwd=4)

curve(deb(3.9,3.9 ,x),add=T,lty=4,col=4,lwd=4)

curve(deb(1.95,2.5015028 ,x),add=T,lty=5,col=5,lwd=4)



legend("topright",c(expression(alpha==1.1~~beta==0.001),
 expression(alpha==1.5~~beta==0.2),
 expression(alpha==1.96~~beta==1.5),
 expression(alpha==3.9~~beta==3.90),
expression(alpha==1.95~~beta==2.50)),

 lty=c(1,2,3,4,5),col=c(1,2,3,4,5),lwd=c(3,3,3,3,3),bty="n")
