# This is the code I used for performing the simulation for EOWEx 
# k: is the sample size
# Change k and the set of the parameters you will get the disered results
##install.packages("DEoptim")
library(DEoptim)

k=250
d<-array(0,c(100,k))
 for(i in 1:100){
alpha<-1.9
beta<- 0.75
p<-runif(k)
d[i,]<-(1-(1-p)^(1/log(alpha)))^(1/beta)   
 }

##############1-Method of MLE##############################
##########################################################

mle50<-array(0,c(100,2))
for(j in 1:100){
FG<-function(theta,datta){
x<-datta 
n<-length(x)
alpha<-theta[1]
beta<-theta[2]

fd<-(((1+x)^(beta-1)) *((1-x)^(alpha-1))*(alpha-beta+x*(alpha+beta)))
FG<--sum(log(fd)) 
FG 
}                                                   
mle50[j,]<-as.vector(DEoptim(FG, lower=c(0.8, 0.35), upper=c(1.49, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=d[j,])$optim[[1]])

}

mlealpha=mean(mle50[,1])
mlebeta=mean(mle50[,2])


mlealphaMSE=mean((mle50[,1]-alpha)^2)
mlebetaMSE=mean((mle50[,2]-beta)^2)



Results1_MLE=c(mlealpha,mlebeta)
Results1_MLE_MSE=c(mlealphaMSE,mlebetaMSE)



##############2- Method of Maximum Product of Spacings###############
###############################################################
ps50<-array(0,c(100,2))
for(j in 1:100){
pGp<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]



D0<-1-(((1+(x[1]))^beta) *((1-(x[1]))^alpha))
         
DDn<-(((1+(x[n]))^beta) *((1-(x[n]))^alpha))
  
D    <-(1-(((1+(x[c(2:n)]))^beta) *((1-(x[c(2:n)]))^alpha)))-(1-(((1+(x[c(1:n-1)]))^beta) *((1-(x[c(1:n-1)]))^alpha)))
pGp<--mean(log(c(D0,D,DDn)))
pGp
}
ps50[j,]<-as.vector(DEoptim(pGp,  lower=c(0.8, 0.35), upper=c(1.49, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=sort(d[j,]))$optim[[1]])
}

Malpha=mean(ps50[,1])
Mbeta=mean(ps50[,2])


MalphaMSE=mean((ps50[,1]-alpha)^2)
MbetaMSE=mean((ps50[,2]-beta)^2)


Results1_M=c(Malpha,Mbeta)
Results1_M_MSE=c(MalphaMSE,MbetaMSE)

###############3-Method OLS######################
#################################################
MOLS50<-array(0,c(100,2))
MMOL<-numeric(100)
for(j in 1:100){
FG4<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]

fd<-((1-(((1+x)^beta) *((1-x)^alpha)))-(c(1:n)/(n+1)))^(2)
FG4<-sum(fd)
FG4
}
MOLS50[j,]<-as.vector(DEoptim(FG4, lower=c(0.8, 0.35), upper=c(1.49, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=sort(d[j,]))$optim[[1]])
}

Oalpha=mean(MOLS50[,1])
Obeta=mean(MOLS50[,2])


OalphaMSE=mean((MOLS50[,1]-alpha)^2)
ObetaMSE=mean((MOLS50[,2]-beta)^2)


Results1_O=c(Oalpha,Obeta)
Results1_O_MSE=c(OalphaMSE,ObetaMSE)


##############4-Method of Weighted least square################
##########################################################
mwl50<-array(0,c(100,2))
for(j in 1:100){
FG5<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]

we<-(((n+1)^(2)*(n+2))/((n-c(1:n)+1)*c(1:n)))
fd<-we*((1-(((1+x)^beta) *((1-x)^alpha)))-(c(1:n)/(n+1)))^(2)
FG5<-sum(fd)
FG5
}

mwl50[j,]<-as.vector(DEoptim(FG5, lower=c(0.8, 0.35), upper=c(1.49, 0.65),  DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=sort(d[j,]))$optim[[1]])
}

Walpha=mean(mwl50[,1])
Wbeta=mean(mwl50[,2])


WalphaMSE=mean((mwl50[,1]-alpha)^2)
WbetaMSE=mean((mwl50[,2]-beta)^2)


Results1_W=c(Walpha,Wbeta)
Results1_W_MSE=c(WalphaMSE,WbetaMSE)

##############5-Method of Percentiles######################
######################################################
pc50<-array(0,c(100,2))
for(j in 1:100){
pG<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]

p<-c(1:n)/(n+1)

fd<-(x-(1-(1-p)^(1/log(alpha)))^(1/beta))^(2)
pG<-sum(fd)
pG 
}                                                                
                                                            
pc50[j,]<-as.vector(DEoptim(pG, lower=c(0.9, 0.35), upper=c(1.59, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=d[j,])$optim[[1]])

}
Palpha=mean(pc50[,1])
Pbeta=mean(pc50[,2])


PalphaMSE=mean((pc50[,1]-alpha)^2)
PbetaMSE=mean((pc50[,2]-beta)^2)


Results1_P=c(Palpha,Pbeta)
Results1_P_MSE=c(PalphaMSE,PbetaMSE)

##############6- Cramer Von-Mise distance:######################
##########################################################
cm50<-array(0,c(100,2))
for(j in 1:100){
FG6<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]

fd<-((1-(((1+x)^beta) *((1-x)^alpha)))-((2*c(1:n)-1)/(2*n)))^(2)
FG6<-sum(fd)+(1/(12*n))
FG6
}
cm50[j,]<-as.vector(DEoptim(FG6, lower=c(0.8, 0.35), upper=c(1.49, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=sort(d[j,]))$optim[[1]])
}

Calpha=mean(cm50[,1])
Cbeta=mean(cm50[,2])


CalphaMSE=mean((cm50[,1]-alpha)^2)
CbetaMSE=mean((cm50[,2]-beta)^2)


Results1_C=c(Calpha,Cbeta)
Results1_C_MSE=c(CalphaMSE,CbetaMSE)

##############7-Anderson-darling method:######################
##########################################################

AD50<-array(0,c(100,2))
for(j in 1:100){
FG7<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]


D11<-(2*c(1:n)-1)*log(1-(((1+x)^beta) *((1-x)^alpha)))+log(((1+(sort(x,decreasing=T)))^beta) *((1-(sort(x,decreasing=T)))^alpha))

FG7<--n-(1/n)*sum(D11)
FG7
}
AD50[j,]<-as.vector(DEoptim(FG7, lower=c(0.8, 0.25), upper=c(1.49, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=sort(d[j,]))$optim[[1]])
}


Aalpha=mean(AD50[,1])
Abeta=mean(AD50[,2])


AalphaMSE=mean((AD50[,1]-alpha)^2)
AbetaMSE=mean((AD50[,2]-beta)^2)


Results1_A=c(Aalpha,Abeta)
Results1_A_MSE=c(AalphaMSE,AbetaMSE)


##############8-RADE ######################
###########################################
RAD150<-array(0,c(100,2))
for(j in 1:100){
FG8<-function(theta,datta){
x<-datta
n<-length(x)
alpha<-theta[1]
beta<-theta[2]


D1<-(1-(((1+x)^beta) *((1-x)^alpha)))
D<-(2*c(1:n)-1)*log((1-(((1+(sort(x,decreasing=T)))^beta) *((1-(sort(x,decreasing=T)))^alpha))))
FG8<-(n/2)-n^(-1)*sum(D)-2*sum(D1)
FG8
}
RAD150[j,]<-as.vector(DEoptim(FG8,lower=c(0.8, 0.35), upper=c(1.49, 0.65), DEoptim.control(NP = 50,itermax=50,F=1.2,CR=0.7,trace=FALSE),datta=sort(d[j,]))$optim[[1]])
}

Halpha=mean(RAD150[,1])
Hbeta=mean(RAD150[,2])


HalphaMSE=mean((RAD150[,1]-alpha)^2)
HbetaMSE=mean((RAD150[,2]-beta)^2)


Results1_H=c(Halpha,Hbeta)
Results1_H_MSE=c(HalphaMSE,HbetaMSE)


##############################################################
################ Results #####################################
##############################################################
###  install.packages("formattable")
library(formattable)

RESULTS_Alpha = matrix( 
  c(mlealpha, Malpha, Oalpha, Walpha, Palpha, Calpha, Aalpha, Halpha, mlealphaMSE, MalphaMSE, OalphaMSE, WalphaMSE, PalphaMSE, CalphaMSE, AalphaMSE, HalphaMSE), 
   nrow=2,  ncol=8, byrow = TRUE)    
RESULTS_Beta = matrix( 
  c(mlebeta,   Mbeta,    Obeta, Wbeta, Pbeta,  Cbeta,    Abeta,   Hbeta,   mlebetaMSE, MbetaMSE, ObetaMSE, WbetaMSE, PbetaMSE, CbetaMSE, AbetaMSE, HbetaMSE), 
   nrow=2,  ncol=8, byrow = TRUE)    
  

RESULTS_Alpha= formattable(RESULTS_Alpha, digits = 3, format = "f")
RESULTS_Beta= formattable(RESULTS_Beta, digits = 3, format = "f")


RESULTS_Alpha
RESULTS_Beta


