for change data and pdf and cdf we get variance - covariance matrix for any distribution.

######################## DATA SET ####################################


x=c(0.0009, 0.004, 0.0142, 0.0221, 0.0261, 0.0418, 0.0473,
0.0834, 0.1091, 0.1252, 0.1404, 0.1498, 0.175, 0.2031, 0.2099, 0.2168, 0.2918,
0.3465, 0.4035, 0.6143)

n=length(x)
##############################
library(fitdistrplus)

dgpl=function(x,beta,alpha)
{


f=(beta*x^(beta-1)*alpha^(log(1-x^beta))*log(alpha))/(1-x^beta)


}

pgpl=function(q,beta,alpha){

F=1-alpha^(log(1-q^beta))
}

qgpl=function(p,beta,alpha){
f=function(p){
g=function(x,p) pgpl(x,beta,alpha)-p
uniroot(g, c(0, 1), p=p)$root
}
apply(as.matrix(p), 1, f)
}

fitg1 <-fitdist(x, "gpl",optim.method="SANN", start=list(  alpha=27.7856622,beta= 0.7506636 ), method="mle")
plot(fitg1, demp =T)

par (mfrow=c (2,2))



ppcomp(fitg1,fitcol=2,legendtext="NAP",lwd=3)
qqcomp(fitg1,fitcol=2,legendtext="NAP",lwd=3)
denscomp(fitg1,fitcol=2,legendtext="NAP",fitlwd=3)

cdfcomp(fitg1,fitcol=2,legendtext="NAP",fitlwd=3)

box()
summary(fitg1)
vcov( fitg1, part = "outcome" )

box()
	


